export class Languages {
   static languages: string[] = Languages.languages || [];
}

export const languages = Languages.languages;
